use axplat::Uart;
use axconfig_macros::config;

pub struct Sg2002Uart;

impl Sg2002Uart {
    pub fn init() {
        let base = config!(uart.base_addr as usize);
        // 在这里实现串口初始化
    }
}

impl Uart for Sg2002Uart {
    fn putc(&self, c: u8) {
        let base = config!(uart.base_addr as usize);
        // 在这里实现字符输出
    }

    fn getc(&self) -> Option<u8> {
        let base = config!(uart.base_addr as usize);
        // 在这里实现字符读取
    }
}