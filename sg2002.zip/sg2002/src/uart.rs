use axplat::Uart;
use axconfig_macros::config;

pub struct Sg2002Uart;

impl Sg2002Uart {
    pub fn init() {
        let base = config!(uart.base_addr as usize);
        // 初始化串口（设置波特率、数据位等）
        unsafe {
            // 1. 关闭串口
            core::ptr::write_volatile((base + 3) as *mut u8, 0x00);
            // 2. 设置波特率分频器
            let divisor = (config!(uart.clk_freq) / (16 * config!(uart.baud_rate))) as u16;
            core::ptr::write_volatile((base + 3) as *mut u8, 0x80); // DLAB=1
            core::ptr::write_volatile((base + 0) as *mut u8, (divisor & 0xff) as u8);
            core::ptr::write_volatile((base + 1) as *mut u8, (divisor >> 8) as u8);
            core::ptr::write_volatile((base + 3) as *mut u8, 0x03); // 8N1
        }
    }
}

impl Uart for Sg2002Uart {
    fn putc(&self, c: u8) {
        let base = config!(uart.base_addr as usize);
        unsafe {
            while (core::ptr::read_volatile((base + 5) as *mut u8) & 0x20) == 0 {}
            core::ptr::write_volatile((base + 0) as *mut u8, c);
        }
    }

    fn getc(&self) -> Option<u8> {
        let base = config!(uart.base_addr as usize);
        unsafe {
            if (core::ptr::read_volatile((base + 5) as *mut u8) & 0x01) != 0 {
                Some(core::ptr::read_volatile((base + 0) as *mut u8))
            } else {
                None
            }
        }
    }
}