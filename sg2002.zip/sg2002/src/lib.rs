#![no_std]
#![no_main]

#[macro_use]
extern crate axplat;

mod console;
mod init;
#[cfg(feature = "irq")]
mod irq;
mod mem;
mod power;
mod time;

pub mod config {
    //! Platform configuration.
    axconfig_macros::include_configs!(path_env = "AX_CONFIG_PATH", fallback = "axconfig.toml");
    
    assert_str_eq!(
        PACKAGE,
        env!("CARGO_PKG_NAME"),
        "配置文件中的 PACKAGE 与 Cargo.toml 不匹配！"
    );
}

/// 内核启动入口（CPU 上电第一条指令）
#[unsafe(no_mangle)]
#[link_section = ".text.boot"]
unsafe extern "C" fn _start() -> ! {
    // 1. 关中断
    core::arch::asm!("csrw sie, zero");
    core::arch::asm!("csrw sip, zero");

    // 2. 设置栈指针 sp
    core::arch::asm!(
        "la sp, __stack_top",
        options(nostack, nomem)
    );

    // 3. 清空 BSS 段（全局变量初始化）
    extern "C" {
        static __bss_start: u8;
        static __bss_end: u8;
    }
    let bss_start = &__bss_start as *const u8 as usize;
    let bss_end = &__bss_end as *const u8 as usize;
    let mut p = bss_start;
    while p < bss_end {
        (p as *mut u64).write_volatile(0);
        p += 8;
    }

    // 4. 进入平台初始化 → 启动内核
    init::platform_init();
}