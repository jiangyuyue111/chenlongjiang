use core::arch::asm;

#[no_mangle]
#[link_section = ".text.boot"]
pub extern "C" fn _start() -> ! {
    // 1. 关中断
    unsafe {
        asm!("csrw sie, zero");
        asm!("csrw sip, zero");
    }

    // 2. 设置栈指针
    unsafe {
        extern "C" {
            static __stack_top: u8;
        }
        asm!("la sp, {}", in(reg) &__stack_top);
    }

    // 3. 调用 Rust 入口
    rust_entry();

    // 卡死，防止意外返回
    loop {}
}

#[no_mangle]
pub extern "C" fn rust_entry() -> ! {
    // 初始化平台
    crate::uart::init();
    axruntime_main();
}